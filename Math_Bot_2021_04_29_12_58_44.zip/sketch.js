class Bot{ 

}
let x;
let y;
let xv;
let yv;
class Main{}
let buttonA;
let buttonB;
let buttonC;
let buttonD;
let answer;
let qCount= ["2 * 3","4 / 2",""];
let i = 0;
let div;

function setup() {
  createCanvas(400, 400);
  buttonA = createButton("A.",1);
  buttonA.mousePressed(clicked); 
  buttonB = createButton("B.");
  buttonB.mousePressed(clicked); 
  buttonC = createButton("C.");
  buttonC.mousePressed(clicked); 
  buttonD = createButton("D.");
  buttonD.mousePressed(clicked); 
  div = createDiv("");
  div.html("what is "+ qCount[i]+ "?");
  
  
div.style('font-size', '16px');
div.position(10, 0);

}
function clicked() {
  i = i + 1;
  div.html("what is "+ qCount[i]+ "?");
}
function move(){
  if (mouseX < x){
    x=x+1;
  }
  if(mouseX > x){
    x=x-1;
  }
}

 function mousePressed(move){
   
}

function draw() {
  background(100,200,230);
  
  rect(50,50,20,20);
  move();
}