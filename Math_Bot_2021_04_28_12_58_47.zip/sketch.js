class Bot{ 

}

class Main{}
let numA;
let numB;
let numC;
let numD;
let answer;
let qCount= ["2 * 3","4 / 2"];



function setup() {
  createCanvas(400, 400);
  numA = createButton(" ",1);
  numA.mousePressed()
  numB = createButton("B.");
  numC = createButton("C.");
  numD = createButton("D.");
  let div = createDiv("");
  div.html("what is "+ qCount[0]+ "?");
div.style('font-size', '16px');
div.position(10, 0);

}
function question2(qCount){
  if(mousePressed(qCount)){
    qCount[i]
  }
}


function draw() {
  background(100,200,230);
}